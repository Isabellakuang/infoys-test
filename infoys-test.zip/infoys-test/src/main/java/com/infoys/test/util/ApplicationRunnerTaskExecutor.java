package com.infoys.test.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
public class ApplicationRunnerTaskExecutor implements ApplicationRunner {

    @Override
    public void run(ApplicationArguments args){
        InfoysTestOne.printChar("aabcccbbad");
        InfoysTestTwo.printChar("abcccbad");
    }
}
